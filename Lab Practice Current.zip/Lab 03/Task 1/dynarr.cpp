#include "dynarr.h"
#include <iostream>
using namespace std;

template <typename type>
dynArr<type>::dynArr()
{
    data = NULL;
    size = 0;
}

template <typename type>
dynArr<type>::dynArr(int s)
{
    data = new type[s];
    size = s;
}

template <typename type>
dynArr<type>::~dynArr()
{
    delete [] data;
}

template <typename type>
void dynArr<type>::allocate(int s)
{
    data = new type[s];
    size = s;
}

template <typename type>
type dynArr<type>::getValue(int index)
{
    return data[index];
}

template <typename type>
void dynArr<type>::setValue(int index, type value)
{
    data[index] = value;
}
