#include <iostream>
#include "Box.cpp"

using namespace std;

int main()
{
    BOX b1(5, 5, 5), b2(3, 3, 3);

    return 0;
}
