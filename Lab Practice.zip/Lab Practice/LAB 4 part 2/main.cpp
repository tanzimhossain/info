#include <iostream>

using namespace std;

class Complex
{
    private:
    double Real, Imaginary;
    public:
    Complex();
    Complex(double, double);
    Complex operator*(Complex);
    void Print();
};

Complex::Complex()
{
    Real = 0;
    Imaginary = 0;
}

Complex::Complex(double r, double i)
{
    Real = r;
    Imaginary = i;
}

Complex Complex::operator*(Complex a)
{
    Complex t;
    t.Real = Real * a.Real;
    t.Imaginary = Imaginary * a.Imaginary;
    return t;
}

void Complex::Print()
{
    cout << Real << endl;
    cout << Imaginary << endl;
}

int main(void) {
	Complex A(1,1), B(2,3);
	Complex C;
    C = A * B;
    //C = A.operator+(B);
	C.Print();
	return 0;
}
