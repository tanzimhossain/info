#include "unsortedtype.h"
#include "unsortedtype.cpp"
#include <iostream>

using namespace std;

int main()
{
    //Create a list of integers
    UnsortedType<int> a;

    //Insert four items
    a.InsertItem(5);
    a.InsertItem(7);
    a.InsertItem(6);
    a.InsertItem(9);

    int alvi;
    a.GetNextItem(alvi);
    a.GetNextItem(alvi);
    cout << alvi << endl;













































/*
    //Print the list
    int l = a.LengthIs();
    for(int i=0; i<l; i++)
    {
        int temp;
        a.GetNextItem(temp);
        cout << temp << " ";
    }
    cout << endl;
    a.ResetList();

    //Print the length of the list
    cout << a.LengthIs() << endl;

    //Insert one item
    a.InsertItem(1);

    //Print the list
    l = a.LengthIs();
    for(int i=0; i<l; i++)
    {
        int temp;
        a.GetNextItem(temp);
        cout << temp << " ";
    }
    cout << endl;

    //Retrieve 4 and print whether found or not
    int temp2 = 4;
    bool flag;

    a.RetrieveItem(temp2, flag);
    if(flag == true)
        cout << "Item is found" << endl;
    else
        cout << "Item is not found" << endl;

    //Retrieve 5 and print whether found or not
    temp2 = 5;
    a.RetrieveItem(temp2, flag);
    if(flag == true)
        cout << "Item is found" << endl;
    else
        cout << "Item is not found" << endl;

    //Retrieve 9 and print whether found or not
    temp2 = 9;
    a.RetrieveItem(temp2, flag);
    if(flag == true)
        cout << "Item is found" << endl;
    else
        cout << "Item is not found" << endl;

    //Retrieve 10 and print whether found or not
    temp2 = 10;
    a.RetrieveItem(temp2, flag);
    if(flag == true)
        cout << "Item is found" << endl;
    else
        cout << "Item is not found" << endl;

    //Print if the list is full or not
    flag = a.IsFull();
    if(flag == true)
        cout << "List is full" << endl;
    else
        cout << "List is not full" << endl;

    //Delete 5
    a.DeleteItem(5);

    //Print if the list is full or not
    l = a.LengthIs();
    for(int i=0; i<l; i++)
    {
        int temp;
        a.GetNextItem(temp);
        cout << temp << " ";
    }

    flag = a.IsFull();
    if(flag == true)
        cout << "List is full" << endl;
    else
        cout << "List is not full" << endl;

    a.DeleteItem(1);

    l = a.LengthIs();
    for(int i=0; i<l; i++)
    {
        int temp;
        a.GetNextItem(temp);
        cout << temp << " ";
    }


*/
    return 0;
}
