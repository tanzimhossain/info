#ifndef DYNARR_H_INCLUDED
#define DYNARR_H_INCLUDED

template <typename Type>
class dynArr
{
private:
    Type *data;
    int size;
public:
    dynArr<Type>();
    dynArr<Type>(int);
    ~dynArr<Type>();

    void setValue(int, Type);
    Type getValue(int);
};

#endif // DYNARR_H_INCLUDED
