#include <iostream>
#include <string.h>
using namespace std;

int main()
{
    int row, i, j;
    cout << "Enter the no. of rows :: ";
    cin >> row;
    int** arr = new int*[row];
    int *column = new int[row];
    for(i = 0; i < row; i++)
    {
        cout << "Enter the no. of columns :: ";
        cin >> column[i];
        //*arr = new int[column[i]];
        arr[i] = new int[column[i]];
        for(j = 0; j < column[i]; j++)
        {
            cout << "Enter element of arr[" << i << "][" << j << "] :: ";
            cin >> arr[i][j];
        }
    }
    for(i = 0; i < row; i++)
    {
        for(j = 0; j < column[i]; j++)
        {
            cout << "arr[" << i << "][" << j << "] :: " << arr[i][j] << endl;
        }
    }
    delete [] arr;
    return 0;
}

