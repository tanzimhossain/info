#include "StackType.h"
#include "StackType.cpp"
#include <iostream>

using namespace std;

void check_balanced(string st, int N);
void printStack(StackType<int> s);


int main()
{
    /*
    StackType<int> a;
    bool flag = a.IsEmpty();
    if(flag == true)
        cout << "Stack is Empty" << endl;
    else
        cout << "Stack is not Empty" << endl;

    a.Push(5);
    a.Push(7);
    a.Push(4);
    a.Push(2);

    flag = a.IsEmpty();
    if(flag == true)
        cout << "Stack is Empty" << endl;
    else
        cout << "Stack is not Empty" << endl;

    flag = a.IsFull();
    if(flag == true)
        cout << "Stack is Full" << endl;
    else
        cout << "Stack is not Full" << endl;

    printStack(a);
    a.Push(3);
    cout << endl;
    printStack(a);
    cout << endl;

    flag = a.IsFull();
    if(flag == true)
        cout << "Stack is Full" << endl;
    else
        cout << "Stack is not Full" << endl;

    a.Pop();
    a.Pop();

    cout << a.Top() << endl;
    */

    string s = "(())))((()";
    int N = s.length();

    // function call

    check_balanced(s, N);

    return 0;
}


void printStack(StackType<int> s)
{
    StackType<int> temp;
    while (s.IsEmpty() == false)
    {
        temp.Push(s.Top());
        s.Pop();
    }

    while (temp.IsEmpty() == false)
    {
        int t = temp.Top();
        cout << t << " ";
        temp.Pop();
        s.Push(t);
    }
}

void check_balanced(string st, int N)
{
    bool ans = true;

    StackType<char> s;

    for (int i = 0; i < N; i++)
        if (st[i] == '(')
            s.Push(st[i]);
        else
        {
            if (!s.IsEmpty())
            {
                // check if top of stack is pair of current element
                char temp = s.Top();

                s.Pop();

                if (st[i] == ')' && temp != '(')
                {
                    ans = false;
                    break;
                }
            }
            // if stack is empty, not balanced
            else
            {
                ans = false;
                break;
            }
        }

    if (!s.IsEmpty())
        ans = false;
    if (ans)
        cout << "balanced";
    else
        cout << "Not balanced";
}
