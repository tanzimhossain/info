#ifndef DYNARR_H_INCLUDED
#define DYNARR_H_INCLUDED

template <typename type>
class dynArr
{
private:
    type *data;
    int size;

public:
    dynArr();
    dynArr(int);
    ~dynArr();
    void allocate(int);
    void setValue(int, type);
    type getValue(int);
};


#endif // DYNARR_H_INCLUDED
