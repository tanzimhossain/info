#include<iostream>

using namespace std;
int isPrime(int);

int main()
{
    /*
    // Task 1 :: Take 2 integer inputs from keyboard and print their sum.
    int a, b;
    cout << "Enter the first integer :: ";
    cin >> a;
    cout << "Enter the second integer :: ";
    cin >> b;
    cout << "Sum of " << a << " + " << b << " = " << a+b;
    */

    /*
    // Task 2 :: Take an integer from keyboard and find its factorial.
    int a, fac = 1;
    cout << "Enter a number :: ";
    cin >> a;
    if(a < 0)
        cout << "Impossible to calculate";
    else
    {
        for (int i = 1; i <= a; i++)
        {
            fac = fac * i;
        }
        cout << a << "! = " << fac;
    }
    */

    /*
    // Task 3 :: Take 2 integer inputs from keyboard and also ask the user for which operation to perform: �+� or �-�or �*�.
    //           Perform the appropriate operation and show the result. (Hint: you can use switch/case)
    int a, b;
    char sign;
    cout << "Enter the first integer :: ";
    cin >> a;
    cout << "Enter the second integer :: ";
    cin >> b;
    cout << "Enter the operator (+ / - / *) :: ";
    cin >> sign;

    switch(sign)
    {
    case '+':
        cout << a << " + " << b << " = " << a+b;
        break;
    case '-':
        cout << a << " - " << b << " = " << a-b;
        break;
    case '*':
        cout << a << " * " << b << " = " << a*b;
        break;
    default:
        cout << "Invalid sign!";
    }
    */

    /*
    // Task 3 :: Write a function isPrime(int n) which checks if �n� is prime or not. Use this function to print all the prime
    //           numbers between 300 to 500.
    int a, check;
    cout << "Enter an integer greater than 1 :: ";
    cin >> a;
    check = isPrime(a);
    if (check == 1)
        cout << a << " is not a prime number!" << endl;
    else
        cout << a << " is a prime number!" << endl;

    for (int i = 300; i <= 500; i++)
    {
        check = isPrime(i);
        if(check == 0)
            cout << i << "  ";
    }*/

    int a,b,c;
    cout<<"Enter two number:";
    cin>>c;
    c=a+b;
    cout<<"The sum:";

    return 0;
}

int isPrime(int num)
{
    int flag = 0;
    for(int i=2 ; i < num/2 ; i++)
    {
        if(num%i == 0)
        {
            flag = 1;
            break;
        }
    }
    return flag;
}

