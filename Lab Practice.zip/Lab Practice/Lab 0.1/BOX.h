#ifndef BOX_H
#define BOX_H

class BOX
{
private:
    int h, w, l;
public:
    BOX(int, int, int);
    void volume();
};

#endif // BOX_H
