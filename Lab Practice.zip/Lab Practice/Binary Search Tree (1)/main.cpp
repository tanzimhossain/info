#include "binarysearchtree.cpp"
#include "binarysearchtree.h"
#include <iostream>

using namespace std;

int main()
{
    TreeType<int> tree;
    cout << "Hello world!" << endl;
    return 0;
}
