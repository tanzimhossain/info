#include <iostream>

using namespace std;

int main()
{
    int length, i, temp;
    cout << "Enter array length :: ";
    cin >> length;
    int *arr = new int[length];
    cout << "address of arr[1] = " << *arr;
    cout << "Enter " << length << " integer values" << endl;
    for(i=0; i<length; i++)
    {
        cin >> temp;
        arr[i] = temp;
    }
    cout << "Array elements are :: ";
    for(i=0; i<length; i++)
    {
        cout << arr[i] << "  ";
    }

    delete [] arr;

    return 0;
}
