#include <iostream>
#include <string.h>
using namespace std;

int main()
{
    int row, column;
    cout << "Enter the no. of rows :: ";
    cin >> row;
    cout << "Enter the no. of columns :: ";
    cin >> column;

    char** arr = new char*[row];
    for(int i = 0; i < row; i++)
    {
        fflush(stdin);
        arr[i] = new char[column];
        // Taking character strings as input from the user
        cout << "Enter string " << i+1 << " :: ";
        cin.getline(arr[i],column);
    }
    cout << endl;
    for(int i = 0; i < row; i++)
    {
        cout << "String " << i+1 << " is :: " << arr[i] << endl;
    }
    delete [] arr;
    return 0;
}
