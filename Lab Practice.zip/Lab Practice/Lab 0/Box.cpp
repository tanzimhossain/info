#include "Box.h"

BOX::Box(int x, int y, int z)
{
    h = x;
    w = y;
    l = z;
}

void BOX::volume()
{
    cout << "Volume is " << h*w*l << endl;
}
