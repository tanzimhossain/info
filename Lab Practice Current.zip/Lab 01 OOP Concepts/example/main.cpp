#include "box.cpp"
#include <iostream>

using namespace std;
/*
class Box
{
private:
    int height, width, depth;
public:
    Box(int a, int b, int c)
    {
        height = a;
        width = b;
        depth = c;
    }
    void volume()
    {
        cout << "Volume is = " << height * width * depth << endl;
    }
};
*/
int main()
{
    Box b1(5,5,5);
    b1.volume();
    return 0;
}


