#include "dynarr.h"
#include <iostream>
using namespace std;

int main()
{
    dynArr a1;
    dynArr a2(2,3);
    int i, j, temp;
    cout << "Enter array Element: " << endl;
    for(i = 0; i<2; i++)
    {
        for(j=0; j<3; j++)
        {
            cin >> temp;
            a2.setValue(i, j, temp);
        }
    }
    cout << "Array elements are: " << endl;
    for(i = 0; i<2; i++)
    {
        for(j=0; j<3; j++)
        {
            cout << a2.getValue(i, j) << " ";
        }
        cout << endl;
    }
    cout << endl;
    return 0;
}
