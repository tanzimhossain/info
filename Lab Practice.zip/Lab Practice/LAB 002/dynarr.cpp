#include "dynarr.h"
#include <iostream>
using namespace std;

template <typename Type>
dynArr<Type>::dynArr()
{
    data = NULL;
    size = 0;
}

template <typename Type>
dynArr<Type>::dynArr(int s)
{
    data = new Type[s];
    size = s;
}

template <typename Type>
dynArr<Type>::~dynArr()
{
    delete [] data;
}

template <typename Type>
Type dynArr<Type>::getValue(int index)
{
    return data[index];
}

template <typename Type>
void dynArr<Type>::setValue(int index, Type value)
{
    data[index] = value;
}
