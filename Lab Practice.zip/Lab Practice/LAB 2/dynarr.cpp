#include "dynarr.h"
#include <iostream>
using namespace std;

dynArr::dynArr()
{
    data = NULL;
    row = 0;
    column = 0;
}
dynArr::dynArr(int r, int c)
{
    data = new int*[r];
    for (int i = 0; i < r; i++) {

        data[i] = new int[c];
    }
    row = r;
    column = c;
}
dynArr::~dynArr()
{
    delete [] data;
}
int dynArr::getValue(int r_index, int c_index)
{
    return data[r_index][c_index];
}
void dynArr::setValue(int r_index, int c_index, int value)
{
    data[r_index][c_index] = value;
}
/*void dynArr::allocate(int s)
{
    delete []data;
    data = new int[s];
    size = s;
}*/
