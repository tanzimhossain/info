#include <iostream>
#include "stacktype.h"
#include "stacktype.cpp"

using namespace std;

int precedence(char op){
    if(op == '+'||op == '-')
    return 1;
    if(op == '*'||op == '/')
    return 2;
    return 0;
}

int operation(int a, int b, char op){
    switch(op){
        case '+': return a + b;
        case '-': return a - b;
        case '*': return a * b;
        case '/': return a / b;
    }
}

void evaluate(string exp){
    int i;

    StackType <int> values;

    StackType <char> ops;

    for(i = 0; i < exp.length(); i++){

        if(exp[i] == ' ')
            continue;

        else if(exp[i] == '('){
            ops.Push(exp[i]);
        }

        else if(isdigit(exp[i])){
            int val = 0;

            while(i < exp.length() &&
                        isdigit(exp[i]))
            {
                val = (val*10) + (exp[i]-'0');
                i++;
            }

            values.Push(val);
            i--;
        }

        else if(exp[i] == ')')
        {
            while(!ops.IsEmpty() && ops.Top() != '(')
            {
                int val2 = values.Top();
                values.Pop();

                int val1 = values.Top();
                values.Pop();

                char op = ops.Top();
                ops.Pop();

                values.Push(operation(val1, val2, op));
            }

            if(!ops.IsEmpty())
               ops.Pop();
        }

        else
        {
            while(!ops.IsEmpty() && precedence(ops.Top())
                                >= precedence(exp[i])){
                int val2 = values.Top();
                values.Pop();

                int val1 = values.Top();
                values.Pop();

                char op = ops.Top();
                ops.Pop();

                values.Push(operation(val1, val2, op));
            }

            ops.Push(exp[i]);
        }
    }

    while(!ops.IsEmpty()){
        int val2 = values.Top();
        values.Pop();

        int val1 = values.Top();
        values.Pop();

        char op = ops.Top();
        ops.Pop();

        values.Push(operation(val1, val2, op));
    }

    cout << values.Top() << endl;

}

int main() {
    evaluate("5 + 2 * 6");
    evaluate("2 * ( 2 + 5 )");
    evaluate("9 * ( 2 + 2 ) / 6");
    evaluate("2 * 3 + 4 * ( 5 - 6 )");
    return 0;
}
