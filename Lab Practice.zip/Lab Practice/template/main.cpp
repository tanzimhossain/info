#include "dynarr.h"
#include <iostream>

using namespace std;

int main()
{
    dynArr<int> a(5);
    return 0;
}
