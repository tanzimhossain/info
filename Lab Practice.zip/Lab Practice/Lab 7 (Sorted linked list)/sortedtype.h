//Md. Tanzim Hossain
//tanzim.hossain@northsouth.edu

#ifndef SORTEDTYPE_H_INCLUDED
#define SORTEDTYPE_H_INCLUDED

template <class ItemType>
class SortedType
{
    struct NodeType
    {
        ItemType seconds, minutes, hours;
        NodeType* next;
    };
    public:
        SortedType();
        ~SortedType();
        bool IsFull();
        int LengthIs();
        void MakeEmpty();
        void InsertItem(ItemType,ItemType,ItemType);
        void DeleteItem(ItemType,ItemType,ItemType);
        void ResetList();
        void GetNextItem(ItemType&,ItemType&,ItemType&);
    private:
        NodeType* listData;
        int length;
        NodeType* currentPos;
};

#endif // SORTEDTYPE_H_INCLUDED
