#ifndef BOX_H_INCLUDED
#define BOX_H_INCLUDED

class BOX
{
private:
    int h, w, d;
public:
    BOX(int a, int b, int c);
    void volume();
};

#endif // BOX_H_INCLUDED
