#include "dynarr.h"
#include <iostream>
using namespace std;

template <class T>
dynArr<T>::dynArr()
{
    data = NULL;
    Size = 0;
}
template <class T>
dynArr<T>::dynArr(int s)
{
    data = new T[s];
    Size = s;
}
template <class T>
dynArr<T>::~dynArr()
{
    delete [] data;
}
template <class T>
void dynArr<T>::incrArraySize(int incr){
    T *temp;
    temp = new T[Size+incr];
    for(int i=0;i<Size;i++)
        temp[i] = data[i];
    Size+=incr;
    delete [] data;
    data = temp;
}
template <class T>
T dynArr<T>::getValue(int index)
{
    return data[index];
}
template <class T>
void dynArr<T>::setValue(int index, T value)
{
    data[index] = value;
}
