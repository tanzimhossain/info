#include <iostream>
#include "quetype.h"
#include "quetype.cpp"

using namespace std;

int main()
{
    QueType<int> a(5);
    bool flag;
    flag = a.IsEmpty();
    if(flag)
        cout << "Queue is Empty" << endl;
    else
        cout << "Queue is not Empty" << endl;

    a.Enqueue(5);
    a.Enqueue(7);
    a.Enqueue(4);
    a.Enqueue(2);

    flag = a.IsEmpty();
    if(flag)
        cout << "Queue is Empty" << endl;
    else
        cout << "Queue is not Empty" << endl;


    flag = a.IsFull();
    if(flag)
        cout << "Queue is Full" << endl;
    else
        cout << "Queue is not Full" << endl;

    a.Enqueue(6);

    a.Print();

    flag = a.IsFull();
    if(flag)
        cout << "Queue is Full" << endl;
    else
        cout << "Queue is not Full" << endl;
    return 0;
}
