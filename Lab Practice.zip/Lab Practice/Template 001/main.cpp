//#include "dynarr.h"
//#include "dynarr.cpp"
#include <iostream>
using namespace std;

/*int main()
{
    dynArr<int> di(10);
    dynArr<double> dd(10);
    int i;

    for(i=0;i<10;i++)
    {
        di.setValue(i,3*i+1);
        dd.setValue(i,7.29*i/1.45);
    }
    for(i=0;i<10;i++)
        cout <<di.getValue(i)<<" "<<dd.getValue(i)<< endl;
    return 0;
}
*/

class Complex
{
    private:
    double Real, Imaginary;
    public:
    Complex();
    Complex(double, double);
    Complex operator*(Complex);
    void Print();
};

Complex::Complex()
{
    Real = 0;
    Imaginary = 0;
}

Complex::Complex(double r, double i)
{
    Real = r;
    Imaginary = i;
}

Complex Complex::operator*(Complex a)
{
    Complex t;
    t.Real = Real * a.Real;
    t.Imaginary = Imaginary * a.Imaginary;
    return t;
}

void Complex::Print()
{
    cout << Real << endl;
    cout << Imaginary << endl;
}

int main(void) {
	Complex A(1,1), B(2,3);
	Complex C;
    //C = A * B;
    C = A.operator*(B);
	C.Print();
	return 0;
}
