#include "dynarr.h"
#include <iostream>

using namespace std;

int main()
{
    int num, i;
    //dynArr<int> d1;
    dynArr<int> d2(5);
    cout << "Enter array element: " << endl;
    for(i=0; i<5; i++)
    {
        cin >> num;
        d2.setValue(i, num);
    }

    cout << "Array Elements are: ";
    for(i=0; i<5; i++)
    {
        cout << d2.getValue(i) << " ";
    }
    cout << endl;

    return 0;
}

