#include <iostream>
using namespace std;

template <class T>
class dynArr
{
private:
    T *data;
    int size;
public:
    dynArr<T>(int);
    ~dynArr<T>();
    void setValue(int, T);
    T getValue(int);
};

template <class T>
dynArr<T>::dynArr(int s)
{
    data = new T[s];
    size = s;
}

template <class T>
dynArr<T>::~dynArr()
{
    delete [] data;
}

template <class T>
T dynArr<T>::getValue(int index)
{
    return data[index];
}

template <class T>
void dynArr<T>::setValue(int index, T value)
{
    data[index] = value;
}
