#include <iostream>
#include "unsortedtype.h"
#include "unsortedtype.cpp"

using namespace std;

int main()
{
    UnsortedType<int> a, b, c;
    int m, n, i, j, temp;
    cout << "Enter the value on m: ";
    cin >> m;
    for (i=0; i<m; i++)
    {
        cin >> temp;
        a.InsertItem(temp);
    }

    cout << "Enter the value on n: ";
    cin >> n;
    for (i=0; i<n; i++)
    {
        cin >> temp;
        b.InsertItem(temp);
    }
    a.ResetList();
    b.ResetList();

    i = 0;
    j = 0;
    int temp1, temp2;
    a.GetNextItem(temp1);
    cout << "temp1 = " << temp1 <<endl;
    b.GetNextItem(temp2);
    cout << "temp2 = " << temp2 <<endl;
    while (i < m && j < n)
    {
        if (temp1 <= temp2)
        {
            c.InsertItem(temp1);
            cout << "c.InsertItem(temp1)" << temp1 <<endl;
            a.GetNextItem(temp1);
            cout << "temp1 = " << temp1 <<endl;
            i++;
        }
        else
        {
            c.InsertItem(temp2);
            cout << "c.InsertItem(temp2)" << temp2 <<endl;
            b.GetNextItem(temp2);
            cout << "temp2 = " << temp2 <<endl;
            j++;
        }
    }
    cout << "i = " << i << ", j = " << j << endl;
    while (i < m)
    {
        a.GetNextItem(temp1);
        cout << "temp1 = " << temp1 <<endl;
        c.InsertItem(temp1);
        i++;
    }

    while (j < n)
    {
        b.GetNextItem(temp2);
        cout << "temp1 = " << temp1 <<endl;
        c.InsertItem(temp2);
        j++;
    }
    c.ResetList();
    int len = c.LengthIs();
    cout << "Merged List: ";
    for(i=0; i<len; i++)
    {
        c.GetNextItem(temp);
        cout << temp << " ";
    }
    cout << endl;
    return 0;
}
