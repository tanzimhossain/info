#include "dynarr.h"
#include <iostream>

using namespace std;

int main()
{
    dynArr a1, a2(5);
    int i, temp;
    for(i=0; i<5; i++)
    {
        cout << "Enter integer " << i+1 << " :: ";
        cin >> temp;
        a2.setValue(i, temp);
    }
    cout << endl << "Array elements are :: ";
    for(i=0; i<5; i++)
    {
        cout << a2.getValue(i) << "  ";
    }
    return 0;
}
