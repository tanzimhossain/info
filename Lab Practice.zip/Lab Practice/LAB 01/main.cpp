#include <iostream>

using namespace std;

int main()
{
    int a, b, i, j;
    cout << "Enter row size: ";
    cin >> a;
    //cout << "Enter column size: ";
    //cin >> b;

    char **arr = new char*[a];
    for(i=0; i<a; i++)
    {
        cin >> b;
        arr[i] = new char[b];
    }

    return 0;
}
