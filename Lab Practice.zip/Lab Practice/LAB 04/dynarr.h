#ifndef DYNARR_H_INCLUDED
#define DYNARR_H_INCLUDED

template <class T>
class dynArr
{
    private:
    T *data;
    int Size;

    public:
    dynArr();
    dynArr(int);
    ~dynArr();
    void incrArraySize(int);
    void setValue(int, T);
    T getValue(int);
};

#endif // DYNARR_H_INCLUDED

