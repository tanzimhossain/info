#include "BOX.h"
#include<iostream>

using namespace std;

BOX::BOX(int a, int b, int c)
{
    h = a;
    w = b;
    d = c;
}
void BOX::volume()
{
    cout << "Volume is = " << h*w*d << endl;
}
