#include <iostream>
#include "BOX.h"

using namespace std;

int main()
{
    BOX b1(2, 2, 2);
    b1.volume();
    return 0;
}
