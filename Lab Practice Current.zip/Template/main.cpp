#include <iostream>
#include "dynarr.h"
#include "dynarr.cpp"
using namespace std;

int main()
{
    dynArr<int> d(5);
    return 0;
}
