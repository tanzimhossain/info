#include <iostream>
#include "BOX.h"
using namespace std;

BOX::BOX(int x, int y, int z)
{
    h = x;
    w = y;
    l = z;
}

void BOX::volume()
{
    cout << "Volume is " << h*w*l << endl;
}
