#ifndef STUDENTINFO_H_INCLUDED
#define STUDENTINFO_H_INCLUDED

const int MAX_ITEMS = 10;
template <class ItemType>class studentInfo
{
public :
    studentInfo();
    void MakeEmpty();
    bool IsFull();
    int LengthIs();
    void InsertItem(ItemType);
    void DeleteItem(ItemType);
    void RetrieveItem(ItemType&, bool&);
    void ResetList();
    void GetNextItem(ItemType&);
private:
    ItemType ID;
    string Name;
    float CGPA;
    int currentPos;
    int length;
    ItemType info[MAX_ITEMS];
    ItemType name[MAX_ITEMS];
    ItemType cgpa[MAX_ITEMS];

};

#endif // STUDENTINFO_H_INCLUDED
