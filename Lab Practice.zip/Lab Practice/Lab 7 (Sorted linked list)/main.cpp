//Md. Tanzim Hossain
//tanzim.hossain@northsouth.edu

#include "sortedtype.h"
#include "sortedtype.cpp"
#include <iostream>

using namespace std;

int main()
{
    //Create a list of objects of class timeStamp.
    SortedType<int> time;

    //Insert 5 time values in the format ssmmhh
    time.InsertItem(15,34,23);
    time.InsertItem(13,13,02);
    time.InsertItem(43,45,12);
    time.InsertItem(25,36,17);
    time.InsertItem(52,02,20);

    //Delete the timestamp 25   36   17
    time.DeleteItem(25,36,17);

    //Print the list
    int ss, mm, hh;
    for(int i=0; i<time.LengthIs(); i++)
    {
        //This print function will work in reverse. Try to solve this issue.
        //Good Luck
        time.GetNextItem(ss,mm,hh);
        cout << ss << ":" << mm << ":" << hh << endl;
    }

    return 0;
}
