#include <iostream>
#include "BOX.h"
using namespace std;

int main()
{
    BOX b1(5, 5, 5), b2(3, 3, 3);
    b1.volume();
    b2.volume();
    return 0;
}
