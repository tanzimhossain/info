#include <iostream>
#include "BOX.h"
using namespace std;

int main()
{
    BOX b1;
    b1.getHeight(5);
    b1.getWidth(5);
    b1.getDepth(5);
    b1.volume();
    return 0;
}
