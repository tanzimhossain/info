#ifndef BOX_H
#define BOX_H

#include <iostream>

using namespace std;

class BOX
{
private:
    int height, width, depth;
public:
    void getHeight(int x)
    {
        height = x;
    }
    void getWidth(int y)
    {
        width = y;
    }
    void getDepth(int z)
    {
        depth = z;
    }
    int volume()
    {
        cout << "Volume = " << height*width*depth << endl;
    }
};

#endif // BOX_H
