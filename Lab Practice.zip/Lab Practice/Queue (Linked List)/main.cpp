#include <iostream>
#include "quetype.h"
#include "quetype.cpp"

using namespace std;
int coins(QueType<int> &, int, int);

int main()
{
    QueType<int> a;
    int n, temp, amount, i;
    cout << "Enter the number of coin types :: ";
    cin >> n;
    for(i=0; i<n; i++)
    {
        cout<< "Enter values of coin " << i+1 << " :: ";
        cin >> temp;
        a.Enqueue(temp);
    }
    cout << "Enter amount :: ";
    cin >> amount;

    temp = coins(a, n, amount);
    cout << endl << "Minimum coins required is :: " << temp << endl;

    return 0;
}


int coins(QueType<int> &a, int n, int amount)
{
    int temp, i;
    if (amount == 0)
    {
        return 0;
    }
    int res = INT_MAX;

    for (i=0; i<n; i++)
    {
        //rear -> 5 3 2 <-front
        a.Dequeue(temp);
        //temp = 2;
        a.Enqueue(temp);
        //rear -> 2 5 3 <-front
        if (temp <= amount)
        {
            int sub_res = coins(a, n, amount-temp);
            if (sub_res != INT_MAX && sub_res + 1 < res)
            {
                res = sub_res + 1;
            }
        }
    }
    return res;
}
