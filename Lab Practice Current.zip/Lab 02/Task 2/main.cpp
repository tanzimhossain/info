#include "dynarr.h"
#include <iostream>

using namespace std;

int main()
{
    dynArr a;
    a.allocate(5);
    a.size_();
    int i, temp;
    for(i=0; i<5; i++)
    {
        cout << "Enter integer " << i+1 << " :: ";
        cin >> temp;
        a.setValue(i, temp);
    }
    cout << endl << "Array elements are :: ";
    for(i=0; i<5; i++)
    {
        cout << a.getValue(i) << "  ";
    }
    return 0;
}
