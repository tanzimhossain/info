#include <iostream>
using namespace std;
int fibonacci(int);

int main()
{
    int num, fib;
    cout << "Enter a number :: ";
    cin >> num;
    if(num<0)
    {
        cout << "Invalid Input" << endl;
        return 0;
    }
    fib = fibonacci(num);
    cout << "fibonacci(" << num << ") :: " << fib << endl;
    return 0;
}

int fibonacci(int num)
{
    if(num <= 1)
		return num;
	else
		return fibonacci(num-1)+fibonacci(num-2);
}
