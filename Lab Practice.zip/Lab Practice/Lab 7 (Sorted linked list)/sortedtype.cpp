//Md. Tanzim Hossain
//tanzim.hossain@northsouth.edu

#include "sortedtype.h"
#include <iostream>
using namespace std;
template <class ItemType>
SortedType<ItemType>::SortedType()
{
    length = 0;
    listData = NULL;
    currentPos = NULL;
}
template <class ItemType>
int SortedType<ItemType>::LengthIs()
{
    return length;
}
template<class ItemType>
bool SortedType<ItemType>::IsFull()
{
    NodeType* location;
    try
    {
        location = new NodeType;
        delete location;
        return false;
    }
    catch(bad_alloc& exception)
    {
        return true;
    }
}

template <class ItemType>
void SortedType<ItemType>::InsertItem(ItemType item1, ItemType item2, ItemType item3)
{
    NodeType* location;
    location = new NodeType;
    location->seconds = item1;
    location->minutes = item2;
    location->hours = item3;
    location->next = listData;
    listData = location;
    length++;
}
template <class ItemType>
void SortedType<ItemType>::DeleteItem(ItemType item1, ItemType item2, ItemType item3)
{
    NodeType* location = listData;
    NodeType* tempLocation;
    if (item1 == location->seconds && item2 == location->minutes && item3 == location->hours)
    {
        tempLocation = location;
        listData = listData->next;
    }
    else
    {
        while (!(item1 == (location->next)->seconds && item2 == (location->next)->minutes && item3 == (location->next)->hours))
            location = location->next;
        tempLocation = location->next;
        location->next = (location->next)->next;
    }
    delete tempLocation;
    length--;
}
template <class ItemType>
void SortedType<ItemType>::MakeEmpty()
{
    NodeType* tempPtr;
    while (listData != NULL)
    {
        tempPtr = listData;
        listData = listData->next;
        delete tempPtr;
    }
    length = 0;
}

template <class ItemType>
SortedType<ItemType>::~SortedType()
{
    MakeEmpty();
}
template <class ItemType>
void SortedType<ItemType>::ResetList()
{
    currentPos = NULL;
}
template <class ItemType>
void SortedType<ItemType>::GetNextItem(ItemType& item1, ItemType& item2, ItemType& item3)
{
    if (currentPos == NULL)
        currentPos = listData;
    else
        currentPos = currentPos->next;
    item1 = currentPos->seconds;
    item2 = currentPos->minutes;
    item3 = currentPos->hours;
}
